import UIKit

import Darwin

//****** QUESTION 1 ******

// 1.a) Declare a variable called  distance of type Double, using type annotation

var distance : Double

// 1.b) Declare a constant called  max Weight of type an Int, with a value of 130, using type annotation

let maxWeight : Int = 130

// 1.c) Print  "Your max weight is xxxx pounds", replacing the xxxx with the value of max Weight. Use String interpolation

print("Your max weight is \(maxWeight) pounds")

print("----------------------------------------------------")

// 1.d) Write Swift source code to print the below in one single print statement
            /*
                Hello, All
                Welcome to Swift Programming..!
            */

print("Hello, All","\rWelcome to Swift Programming..!")

print("----------------------------------------------------")

//****** END OF QUESTION 1 ******



//****** QUESTION 2 ******
// 2.a) Predict what will happen when you try and execute below three statements when you uncomment the third line?

var U = 30
var V = 78.0
//V=U
//Ans: We can not assign value of type Int to value of type Double.

// 2.b) Fix the error in the question 2.a

V = Double(U)
//print(V)
//print("----------------------------------------------------")

//Converts value from Int to Double


//****** END OF QUESTION 2 ******



//****** QUESTION 3 ******
//3.a) Declare three constants x, y, z and assign the values 2, 7, 5. Write a swift code to find the largest number among the three integers.
let x=2
let y=7
let z=5
if x>y && x>z
{
    print("x is greater")
}
else if y>x && y>z
{
    print("y is greater")
}
else
{
print("z is greater")
}
print("----------------------------------------------------")

//3.b) Declare 2 variables a,b and assign values 13, 103. Write a swift code to check whether the last digit of the two given  integer values are same or not.

var a=13
var b=103

if a%10 == b%10
{
    print("Last digit of both a and b are same")
}
else{
    print("Last digit of both a and b are not same")
}
print("----------------------------------------------------")

//****** END OF QUESTION 3 ******



//****** QUESTION 4 ******
//using loops

//4.a) Print the numbers 1 to N in alternative order, one number from the left side (starting with one) and one number from the right side (starting from N down to 1)
//Decalare var N = 10
//expected output is 1 10 2 9 3 8 4 7 5 6

var N = 10
var str=""
for i in 0..<N/2{
     str = str+"\(i+1) " + "\(N-i) "
}
print("\(str)")
print("----------------------------------------------------")

//4.b) If a number C is given, then print the following rhombus
//declare C = 5

//output
// Hint : use terminator in print statements and loops
//    *
//   *
//  ***
// ***
//***
// ***
//  ***
//   *
//    *

var C = 5
for row in 1...C{
    
    for space in (row...C){
        print(" ",terminator:"")
    }
    
    //print("*",terminator: "")
    
    for column in 1...row*2-1{
        
    print("*",terminator:"")
    }
    
    print("")
    
}
for row in (1..<C).reversed(){
    
    for space in (row...C){
        print(" ",terminator:"")
    }
    
    //print("*",terminator: "")
    
    for column in 1...row*2-1{
        
    print("*",terminator:"")
    }
    
    print("")
    
}

print("----------------------------------------------------")

//****** END OF QUESTION 4 ******



//****** QUESTION 5 ******
// Using Strings

//5.a) Declare a String and assign the value of your own, Write a Swift code to add "A" in front of the string and print it. If the string already begins with "A", then simply print it.

var string = "Sushma"
if string[string.startIndex] == "A"
{
    print(string)
}
else
{
    string = "A" + string
    print(string)
}
print("----------------------------------------------------")

//5.b) Declare a String str1 and and assign the value of your own. Write a swift code to add the last character at the front and back of the given string and print it.

var str1 = "Book"

//str1 = str1[str1.index(before: str1.endIndex)] + str1

var lastchar=str1[str1.index(str1.endIndex, offsetBy: -1)]
var las=String(lastchar)

str1 = las+"\(str1)"+las
print(str1)
print("----------------------------------------------------")

//5.c) Declare a String Swift and print them in the reverse order.

var str2 = "Swift"
var ReverseString=String(str2.reversed())
print(ReverseString)
print("----------------------------------------------------")

//5.d) Write a Swift code  to check if the first or last characters are 'a' of a given string, return the given string without those 'a' characters in the first and last, otherwise return the given string.

 //declare var myString1 = "ababa"
 //expected output bab

var myString = "ababa" 
if myString[myString.startIndex] == "a" || myString[myString.index(before: myString.endIndex)] == "a"
{
    if myString[myString.startIndex] == "a"
    {
    myString.remove(at: myString.startIndex)
    }
    if  myString[myString.index(before: myString.endIndex)] == "a"
    {
    myString.remove(at: myString.index(before: myString.endIndex))
    }
    print(myString)
}
else{
    print(myString)
}

//****** END OF QUESTION 5 ******


